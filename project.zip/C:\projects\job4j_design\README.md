# job4j_desing

[![Build Status](https://travis-ci.org/pavilion1900/job4j_design.svg?branch=master)](https://travis-ci.org/pavilion1900/job4j_design)
[![codecov](https://codecov.io/gh/pavilion1900/job4j_design/branch/master/graph/badge.svg?token=HFLRGWBDU1)](https://codecov.io/gh/pavilion1900/job4j_design)